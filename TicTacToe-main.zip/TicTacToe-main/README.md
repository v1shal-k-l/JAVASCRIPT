# TicTacToe
The typical game Tic Tac Toe built using HTML, CSS and JavaScript.
Two players can play this game, and can see who has won or if the match is tied.
They can also reset the game in between or after the game has finished
